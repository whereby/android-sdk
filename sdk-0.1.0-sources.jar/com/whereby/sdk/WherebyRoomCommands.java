package com.whereby.sdk;

public interface WherebyRoomCommands {
    void toggleMicrophoneEnabled();
    void setMicrophoneEnabled(boolean enabled);
    void toggleCameraEnabled();
    void setCameraEnabled(boolean enabled);
}
