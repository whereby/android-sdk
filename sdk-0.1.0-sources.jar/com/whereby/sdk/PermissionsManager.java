package com.whereby.sdk;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.List;

class PermissionsManager {

    static final int PERMISSION_REQUEST_CODE = 1234;
    private static final String[] PERMISSIONS = {
            Manifest.permission.CAMERA,
            Manifest.permission.MODIFY_AUDIO_SETTINGS,
            Manifest.permission.RECORD_AUDIO
    };

    private AlertDialog mAlertDialog;
    boolean mPermissionChecked = false;

    boolean isPendingPermissions(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return false;
        }
        return this.getPendingPermissions(context).length > 0;
    }

    // This could probably use a callback instead of returning a boolean
    boolean onRequestPermissionsResult(@NonNull String[] permissions, @NonNull int[] grantResults, Context context) {
        if (grantResultsContainsDenials(grantResults)) {
            mPermissionChecked = true;
            showPermissionAlert(context);
            return false;
        }
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    String[] getPendingPermissions(Context context) {
        List<String> pendingPermissions = new ArrayList<>();
        for (String permission : this.PERMISSIONS) {
            if (context.checkSelfPermission(permission) == PackageManager.PERMISSION_DENIED) {
                pendingPermissions.add(permission);
            }
        }
        return pendingPermissions.toArray(new String[pendingPermissions.size()]);
    }

    boolean grantResultsContainsDenials(int[] grantResults) {
        for (int result : grantResults) {
            if (result == PackageManager.PERMISSION_DENIED) {
                return true;
            }
        }
        return false;
    }

    void showPermissionAlert(Context context) {
        if (mAlertDialog != null && mAlertDialog.isShowing()) {
            return;
        }
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        alertDialogBuilder.setTitle("Error");
        alertDialogBuilder.setMessage("Permissions for Camera and microphone are needed. Enable them in settings.");
        alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        mAlertDialog = alertDialogBuilder.create();
        mAlertDialog.show();
    }

    void onStop() {
        mPermissionChecked = false;
        hidePermissionAlert();
    }

    void hidePermissionAlert() {
        if (mAlertDialog != null) {
            mAlertDialog.dismiss();
        }
    }
}
