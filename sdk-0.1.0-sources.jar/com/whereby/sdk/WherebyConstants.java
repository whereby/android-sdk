package com.whereby.sdk;

public class WherebyConstants {
    //region public
    public static final String ROOM_CONFIG_KEY = "ROOM_CONFIG_KEY";
    //endregion

    //region package-private
    /**
     * This name is used by Javascript to send events to Android (must match with PWA):
     */
    static final String ANDROID_WEB_APP_INTERFACE_NAME = "AndroidWebAppInterface";

    static final String ANDROID_SDK_PLATFORM_NAME = "android";
    //endregion
}
