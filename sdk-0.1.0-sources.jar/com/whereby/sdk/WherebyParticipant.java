package com.whereby.sdk;

import static com.whereby.sdk.WherebyRoomEventProperties.*;

import org.json.JSONException;
import org.json.JSONObject;

public class WherebyParticipant {

    private String mMetadata;

    public WherebyParticipant(JSONObject json) {
        try {
            if (json.has(ROOM_EVENT_PROPERTY_PARTICIPANT)) {
                JSONObject participant_json = json.getJSONObject(ROOM_EVENT_PROPERTY_PARTICIPANT);
                if (participant_json.has(ROOM_EVENT_PROPERTY_METADATA)) {
                    mMetadata = participant_json.getString(ROOM_EVENT_PROPERTY_METADATA);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //region Getters & Setters
    public void setMetadata(String metadata) {
        this.mMetadata = metadata;
    }

    public String getMetadata() {
        return mMetadata;
    }
    //endregion
}
