package com.whereby.sdk;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.net.URL;

public class WherebyRoomConfig implements Serializable {

    @NonNull
    private URL mUrl;

    private String mDisplayName;
    private String mLanguage;
    private String mMetadata;

    private URL mAvatarUrl;

    private Boolean mMinimalConfigurationEnabled;
    private Boolean mMicrophoneEnabledAtStart;
    private Boolean mCameraEnabledAtStart;
    private Boolean mRoomBackgroundVisible;
    private Boolean mChatButtonVisible;
    private Boolean mPeopleButtonVisible;
    private Boolean mLeaveButtonVisible;
    private Boolean mSubgridLabelsVisible;
    private Boolean mSelfViewPopOutEnabled;
    private Boolean mLogoVisible;
    private Boolean mLockingEnabled;
    private Boolean mParticipantCounterVisible;
    private Boolean mSettingsButtonVisible;
    private Boolean mMoreButtonVisible;
    private Boolean mTopToolbarVisible;
    private Boolean mBottomToolbarVisible;
    private Boolean mBreakoutGroupsHostControlsVisible;
    private Boolean mTimerVisible;
    private Boolean mPreCallReviewScreenEnabled;

    /**
     * Intended to be passed to WherebyRoomFragment as an argument.
     *
     * @param mUrl
     */
    public WherebyRoomConfig(@NonNull URL mUrl) {
        this.mUrl = mUrl;
    }

    //region Getters & Setters
    @NonNull
    public URL getUrl() {
        return mUrl;
    }

    /**
     * Set the display name for a participant instead of prompting the user for this information.
     * Use case: A participant’s name may be known before they join the meeting. Setting the
     * displayName will save the user from entering their name again.
     *
     * @param displayName
     */
    public void setDisplayName(String displayName) {
        this.mDisplayName = displayName;
    }

    public String getDisplayName() {
        return mDisplayName;
    }

    /**
     * Set the meeting UI language to match your product or service.
     *
     * @param language
     */
    public void setLanguage(String language) {
        this.mLanguage = language;
    }

    public String getLanguage() {
        return mLanguage;
    }

    /**
     * Set the avatar / profile picture of the participant instead of the automatically assigned
     * name initials. The image can be a .png or .jpeg, and must be a square maximum of 64x64.
     * Note: You must make sure to list the origin of the image URL in the allowed domains section
     * of the dashboard. The image URL must be https and cannot contain query params.
     *
     * @param avatarUrl
     */
    public void setAvatarUrl(URL avatarUrl) {
        this.mAvatarUrl = avatarUrl;
    }

    public URL getAvatarUrl() {
        return mAvatarUrl;
    }

    /**
     * Can be used to pass any URL-encoded string so that it is included in the corresponding
     * webhooks. The decoded string has a limit of 512 characters.
     * Use case: Set it to the user’s ID so that you can easily track through webhooks when a
     * particular user joins or leaves a room.
     *
     * @param metadata
     */
    public void setMetadata(String metadata) {
        this.mMetadata = metadata;
    }

    public String getMetadata() {
        return mMetadata;
    }

    /**
     * The minimal configuration applies a combination of UI adjustments to simplify the embedded
     * meeting interface.
     * Hidden items: Status bar, chat button, leave button, and Whereby’s branding.
     * Shown items: Video and audio buttons.
     * For further adjustments, additional parameters can be combined with minimal configuration.
     *
     * @param enabled
     */
    public void setMinimalConfigurationEnabled(Boolean enabled) {
        this.mMinimalConfigurationEnabled = enabled;
    }

    public Boolean isMinimalConfigurationEnabled() {
        return mMinimalConfigurationEnabled;
    }

    /**
     * Participants join the meeting with their microphone on (enabled) or off (disabled), they can
     * then turn it off/on whenever they want.
     * Use case: A presentation is being given in a big meeting where attendees are not expected to
     * participate verbally.
     *
     * @param enabled
     */
    public void setMicrophoneEnabledAtStart(Boolean enabled) {
        this.mMicrophoneEnabledAtStart = enabled;
    }

    public Boolean isMicrophoneEnabledAtStart() {
        return mMicrophoneEnabledAtStart;
    }

    /**
     * Participants join the meeting with their camera on (enabled) or off (disabled), they can then
     * turn it off/on whenever they want.
     * Use case: A sales representative showcasing a product to a customer relaxing at home.
     *
     * @param enabled
     */
    public void setCameraEnabledAtStart(Boolean enabled) {
        this.mCameraEnabledAtStart = enabled;
    }

    public Boolean isCameraEnabledAtStart() {
        return mCameraEnabledAtStart;
    }

    /**
     * Enable (show) or disable (hide) the default meeting background.
     * Use case: Hiding the meeting background allows the meeting to appear more integrated by
     * allowing the app or service’s branding shine through as the new background.
     *
     * @param enabled
     */
    public void setRoomBackgroundVisible(Boolean enabled) {
        this.mRoomBackgroundVisible = enabled;
    }

    public Boolean isRoomBackgroundVisible() {
        return mRoomBackgroundVisible;
    }

    /**
     * Show/hide the chat button. Messages are not stored after the meeting has ended.
     *
     * @param visible
     */
    public void setChatButtonVisible(Boolean visible) {
        this.mChatButtonVisible = visible;
    }

    public Boolean isChatButtonVisible() {
        return mChatButtonVisible;
    }

    /**
     * Show/hide the people button.
     * Use case: The people button shows the participant list, which can be useful for bulk
     * management of participants in bigger meetings.
     *
     * @param visible
     */

    public void setPeopleButtonVisible(Boolean visible) {
        this.mPeopleButtonVisible = visible;
    }

    public Boolean isPeopleButtonVisible() {
        return mPeopleButtonVisible;
    }

    /**
     * Show/hide the leave button.
     * Use case: Can be used if you want to control the leave flow in other ways, like adding a
     * button outside the embedded room to control what happens when users leave the call.
     *
     * @param visible
     */
    public void setLeaveButtonVisible(Boolean visible) {
        this.mLeaveButtonVisible = visible;
    }

    public Boolean isLeaveButtonVisible() {
        return mLeaveButtonVisible;
    }

    /**
     * Show/hide the name labels for the participants in the subgrid.
     * Use case: Set this to visible to show name labels for the participants that are rendered as
     * small tiles in the subgrid. Makes it easier to distinguish participants with their camera
     * off.
     *
     * @param visible
     */
    public void setSubgridLabelsVisible(Boolean visible) {
        this.mSubgridLabelsVisible = visible;
    }

    public Boolean isSubgridLabelsVisible() {
        return mSubgridLabelsVisible;
    }

    /**
     * Float the self view to the bottom right.
     * Use case: Floating the self view to the bottom right maximizes the space for other meeting
     * participants.
     *
     * @param enabled
     */
    public void setSelfViewPopOutEnabled(Boolean enabled) {
        this.mSelfViewPopOutEnabled = enabled;
    }

    public Boolean isSelfViewPopOutEnabled() {
        return mSelfViewPopOutEnabled;
    }

    /**
     * Show/hide the logo in the room header.
     * Use case: Control whether or not your company logo is displayed in the room header.
     *
     * @param visible
     */
    public void setLogoVisible(Boolean visible) {
        this.mLogoVisible = visible;
    }

    public Boolean isLogoVisible() {
        return mLogoVisible;
    }

    /**
     * Enable/disable the room lock feature.
     * Use case: When disabled the lock button won’t be displayed in the room header. Also, hosts
     * won’t be able to lock/unlock the room through the settings menu or the keyboard shortcut.
     *
     * @param enabled
     */
    public void setLockingEnabled(Boolean enabled) {
        this.mLockingEnabled = enabled;
    }

    public Boolean isLockingEnabled() {
        return mLockingEnabled;
    }

    /**
     * Show/hide the participant counter.
     * Use case: Will display the current and maximum number of participants in the room, e.g.
     * “2/4” or “13/100”.
     *
     * @param visible
     */
    public void setParticipantCounterVisible(Boolean visible) {
        this.mParticipantCounterVisible = visible;
    }

    public Boolean isParticipantCounterVisible() {
        return mParticipantCounterVisible;
    }

    /**
     * Show/hide the settings button.
     * Use case: Control whether or not the settings button is displayed in the room header.
     *
     * @param visible
     */
    public void setSettingsButtonVisible(Boolean visible) {
        this.mSettingsButtonVisible = visible;
    }

    public Boolean isSettingsButtonVisible() {
        return mSettingsButtonVisible;
    }

    /***
     * Show/Hide the more (“…”) button.
     * Use case: Control whether or not the more (“…”) button is displayed in the room header.
     *
     * @param visible
     */
    public void setMoreButtonVisible(Boolean visible) {
        this.mMoreButtonVisible = visible;
    }

    public Boolean isMoreButtonVisible() {
        return mMoreButtonVisible;
    }

    /**
     * Show/hide the entire top toolbar.
     * Use case: When using the minimal configuration, the top toolbar is hidden along with many
     * other UI elements. This parameter will cause the top toolbar to reappear, which is required
     * if you want to enable breakout groups, for instance.
     *
     * @param visible
     */
    public void setTopToolbarVisible(Boolean visible) {
        this.mTopToolbarVisible = visible;
    }

    public Boolean isTopToolbarVisible() {
        return mTopToolbarVisible;
    }

    /**
     * Show/hide the entire bottom tool bar.
     * User case: Hiding the bottom toolbar entirely can be useful in cases where you are hoping to
     * control in room items like camera or microphone via your own websites UI.
     * @param visible
     */
    public void setBottomToolbarVisible(Boolean visible) {
        this.mBottomToolbarVisible = visible;
    }

    public Boolean isBottomToolbarVisible() {
        return mBottomToolbarVisible;
    }

    /**
     * Show/hide the Breakout Groups controls for the meeting host.
     * Use case: Combine bigger meetings with smaller, collaborative sessions. Your hosts can start
     * breakout sessions where participants are split into smaller groups.
     *
     * @param visible
     */
    public void setBreakoutGroupsHostControlsVisible(Boolean visible) {
        this.mBreakoutGroupsHostControlsVisible = visible;
    }

    public Boolean isBreakoutGroupsHostControlsVisible() {
        return mBreakoutGroupsHostControlsVisible;
    }

    /**
     * Show/hide the meeting timer.
     * Use case: Enable this to have the meeting timer be displayed in the room. When disabled,
     * room hosts can still activate the meeting timer from the “…” button, unless this button has
     * been hidden.
     *
     * @param visible
     */
    public void setTimerVisible(Boolean visible) {
        this.mTimerVisible = visible;
    }

    public Boolean isTimerVisible() {
        return mTimerVisible;
    }

    /**
     * Determines if users see the pre-call review step.
     * Use case: The pre-call review step will allow users to check their video/audio settings
     * before joining the room.
     *
     * @param enabled
     */
    public void setPreCallReviewScreenEnabled(Boolean enabled) {
        this.mPreCallReviewScreenEnabled = enabled;
    }

    public Boolean isPreCallReviewScreenEnabled() {
        return mPreCallReviewScreenEnabled;
    }
    //endregion
}
