package com.whereby.sdk;

import static com.whereby.sdk.WherebyConstants.*;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;

class WebViewUtils {

    @SuppressLint("SetJavaScriptEnabled")
    public static void configureWebView(WebView webView, Activity activity, WebAppInterface webAppInterface, WherebyRoomConfig roomConfig) {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new CustomWebChromeClient(activity));
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(webAppInterface, ANDROID_WEB_APP_INTERFACE_NAME);

        if (roomConfig != null
                && roomConfig.isRoomBackgroundVisible() != null
                && !roomConfig.isRoomBackgroundVisible()) {
            webView.setBackgroundColor(Color.TRANSPARENT);
        }
    }
}
