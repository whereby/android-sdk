package com.whereby.sdk;

import static com.whereby.sdk.WherebyConstants.*;
import static com.whereby.sdk.WherebyRoomEventProperties.*;
import static com.whereby.sdk.WherebyRoomEventTypes.*;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.fragment.app.Fragment;

import org.json.JSONException;

@SuppressLint("ValidFragment")
public class RoomFragment extends Fragment {
    View mView;

    private final static String TAG = RoomFragment.class.getSimpleName();

    private WebView mWebView;
    private String mUrl_String;
    private WebAppInterface mWebAppInterface;
    private PermissionsManager mPermissionsManager;

    private WherebyEventListener mEventListener;

    //region Fragment lifecycle
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.whereby_room_fragment, container, false);
        mWebView = mView.findViewById(R.id.webView);
        mPermissionsManager = new PermissionsManager();

        Bundle argumentsBundle = getArguments();
        if (argumentsBundle == null || argumentsBundle.getSerializable(ROOM_CONFIG_KEY) == null) {
            showErrorAlertDialog("Failed to load room.");
            return mView;
        }
        WherebyRoomConfig roomConfig = (WherebyRoomConfig) argumentsBundle.getSerializable(ROOM_CONFIG_KEY);
        if (roomConfig.getUrl() == null) {
            showErrorAlertDialog("Room url missing.");
            return mView;
        }
        mUrl_String = new RoomUriBuilder(roomConfig).build().toString();
//        Log.d(TAG, mUrl_String);

        mWebAppInterface = new WebAppInterface();
        mWebAppInterface.setEventListener(message -> onReceivePostMessage(message));

        WebViewUtils.configureWebView(mWebView, getActivity(), mWebAppInterface, roomConfig);
        return mView;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (this.mWebView.getUrl() == null) {
            checkMediaPermissionsAndLoadRoom();
        }
    }

    @Override
    public void onStop() {
        mPermissionsManager.onStop();
        super.onStop();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PermissionsManager.PERMISSION_REQUEST_CODE) {
            if (mPermissionsManager.onRequestPermissionsResult(permissions, grantResults, getContext())) {
                this.loadRoomUrl();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public void onDestroy() {
        mWebView.destroy();
        super.onDestroy();
    }
    //endregion

    //region package-private
    void join() {
        checkMediaPermissionsAndLoadRoom();
    }

    void sendCommand(String command, String args) {
        mWebView.loadUrl("javascript:window.postMessage({ command: \"" + command + "\", args: [" + args + "]})");
    }

    void setEventListener(WherebyEventListener eventListener) {
        this.mEventListener = eventListener;
    }
    //endregion

    //region Private
    void checkMediaPermissionsAndLoadRoom() {
        if (mPermissionsManager == null) {
            return;
        }
        if (!mPermissionsManager.isPendingPermissions(getContext())) {
            this.loadRoomUrl();
        } else if (!mPermissionsManager.mPermissionChecked) {
            requestPermissions(mPermissionsManager.getPendingPermissions(getContext()), PermissionsManager.PERMISSION_REQUEST_CODE);
        }
    }

    private void loadRoomUrl() {
        if (mUrl_String == null) {
            return;
        }
        this.mWebView.loadUrl(mUrl_String);
    }


    void onReceivePostMessage(String message) {
        // Log.d(TAG, message);
        if (mEventListener == null) {
            return;
        }
        WherebyRoomEvent wherebyRoomEvent = new WherebyRoomEvent(message);
        try {
            switch (wherebyRoomEvent.getType()) {
                case ROOM_EVENT_TYPE_READY:
                    mEventListener.onRoomReady();
                    break;
                case ROOM_EVENT_TYPE_JOIN:
                    mEventListener.onLocalParticipantJoined();
                    break;
                case ROOM_EVENT_TYPE_KNOCK:
                    mEventListener.onLocalParticipantKnocked();
                    break;
                case ROOM_EVENT_TYPE_PARTICIPANT_JOIN: {
                    WherebyParticipant participant = new WherebyParticipant(wherebyRoomEvent.getPayload());
                    mEventListener.onRemoteParticipantJoined(participant);
                    break;
                }
                case ROOM_EVENT_TYPE_PARTICIPANT_LEAVE: {
                    WherebyParticipant participant = new WherebyParticipant(wherebyRoomEvent.getPayload());
                    mEventListener.onRemoteParticipantLeave(participant);
                    break;
                }
                case ROOM_EVENT_TYPE_PARTICIPANT_UPDATE:
                    // Ideally, we should have a model class for each type of event, like
                    // WherebyParticipant. For single entry JSON like this one, we can simply
                    // get the property by type.
                    int count = wherebyRoomEvent.getPayload().getInt(ROOM_EVENT_PROPERTY_COUNT);
                    mEventListener.onParticipantCountUpdated(count);
                    break;
                case ROOM_EVENT_TYPE_MICROPHONE_TOGGLE: {
                    boolean enabled = wherebyRoomEvent.getPayload().getBoolean(ROOM_EVENT_PROPERTY_ENABLED);
                    mEventListener.onMicrophoneToggled(enabled);
                    break;
                }
                case ROOM_EVENT_TYPE_CAMERA_TOGGLE: {
                    boolean enabled = wherebyRoomEvent.getPayload().getBoolean(ROOM_EVENT_PROPERTY_ENABLED);
                    mEventListener.onCameraToggled(enabled);
                    break;
                }
                case ROOM_EVENT_TYPE_LEAVE:
                    boolean removed = wherebyRoomEvent.getPayload().getBoolean(ROOM_EVENT_PROPERTY_REMOVED);
                    mEventListener.onLocalParticipantLeft(removed);
                    break;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void showErrorAlertDialog(String message) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());
        alertDialogBuilder.setTitle("Error");
        alertDialogBuilder.setMessage(message);
        alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        alertDialogBuilder.create().show();
    }
    //endregion
}
