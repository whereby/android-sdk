package com.whereby.sdk;

import org.json.JSONObject;

// Should this be an interface with default methods or an abstract class?
public interface WherebyEventListener {
    default void onRoomReady() {}
    default void onLocalParticipantKnocked() {}
    default void onLocalParticipantJoined() {}
    default void onRemoteParticipantJoined(WherebyParticipant participant) {}
    default void onRemoteParticipantLeave(WherebyParticipant participant) {}
    default void onParticipantCountUpdated(int count) {}
    default void onMicrophoneToggled(boolean enabled) {}
    default void onCameraToggled(boolean enabled) {}
    default void onLocalParticipantLeft(boolean isRemoved) {}
}