package com.whereby.sdk;

import static com.whereby.sdk.WherebyConstants.ANDROID_SDK_PLATFORM_NAME;

import android.net.Uri;

import androidx.annotation.Nullable;

import java.net.URL;

class RoomUriBuilder {

    private Uri.Builder mBuilder;

    RoomUriBuilder(WherebyRoomConfig roomConfig) {
        mBuilder = Uri.parse(roomConfig.getUrl().toString()).buildUpon();

        // Mandatory
        appendQueryParameter("sdkVersion", BuildConfig.WHEREBY_VERSION_NAME);
        appendQueryParameter("sdkPlatform", ANDROID_SDK_PLATFORM_NAME);
        appendQueryParameter("skipMediaPermissionPrompt", true);

        // String
        appendQueryParameter("displayName", roomConfig.getDisplayName());
        appendQueryParameter("lang", roomConfig.getLanguage());
        appendQueryParameter("metadata", roomConfig.getMetadata());

        // URL
        appendQueryParameter("avatarUrl", roomConfig.getAvatarUrl());

        // Boolean
        appendQueryParameter("minimal", roomConfig.isMinimalConfigurationEnabled());
        appendQueryParameter("audio", roomConfig.isMicrophoneEnabledAtStart());
        appendQueryParameter("video", roomConfig.isCameraEnabledAtStart());
        appendQueryParameter("background", roomConfig.isRoomBackgroundVisible());
        appendQueryParameter("chat", roomConfig.isChatButtonVisible());
        appendQueryParameter("people", roomConfig.isPeopleButtonVisible());
        appendQueryParameter("leaveButton", roomConfig.isLeaveButtonVisible());
        appendQueryParameter("subgridLabels", roomConfig.isSubgridLabelsVisible());
        appendQueryParameter("floatSelf", roomConfig.isSelfViewPopOutEnabled());
        appendQueryParameter("logo", roomConfig.isLogoVisible());
        appendQueryParameter("locking", roomConfig.isLockingEnabled());
        appendQueryParameter("participantCount", roomConfig.isParticipantCounterVisible());
        appendQueryParameter("settingsButton", roomConfig.isSettingsButtonVisible());
        appendQueryParameter("moreButton", roomConfig.isMoreButtonVisible());
        appendQueryParameter("topToolbar", roomConfig.isTopToolbarVisible());
        appendQueryParameter("bottomToolbar", roomConfig.isBottomToolbarVisible());
        appendQueryParameter("breakout", roomConfig.isBreakoutGroupsHostControlsVisible());
        appendQueryParameter("timer", roomConfig.isTimerVisible());
        appendQueryParameter("precallReview", roomConfig.isPreCallReviewScreenEnabled());
    }

    Uri build() {
        return mBuilder.build();
    }

    //region private
    private void appendQueryParameter(String key, @Nullable String value) {
        if (value == null) {
            return;
        }
        mBuilder.appendQueryParameter(key, value);
    }

    private void appendQueryParameter(String key, @Nullable URL value) {
        if (value == null) {
            return;
        }
        mBuilder.appendQueryParameter(key, value.toString());
    }

    private void appendQueryParameter(String key, @Nullable Boolean value) {
        if (value == null) {
            return;
        }
        mBuilder.appendQueryParameter(key, value ? "on" : "off");
    }
    //endregion
}
