package com.whereby.sdk;

import android.webkit.JavascriptInterface;

interface WepAppMessageListener {
    void onReceivePostMessage(String message);
}

class WebAppInterface {

    private WepAppMessageListener mListener;

    @JavascriptInterface
    public void postMessage(String message) {
        if (mListener != null) {
            mListener.onReceivePostMessage(message);
        }
    }

    void setEventListener(WepAppMessageListener messageListener) {
        this.mListener = messageListener;
    }

}
