package com.whereby.sdk;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

class UrlBuilder {

    private String mUrlString;

    protected URL create(URL roomUrl, WherebyRoomParameters roomParameters) throws MalformedURLException {
        mUrlString = roomUrl.toString(); // Not ideal
        for (Map.Entry entry : roomParameters.toHashMap().entrySet()) {
            addRoomParameterToUrl((String) entry.getKey(), (String) entry.getValue());
        }
        return new URL(mUrlString);
    }

    private void addRoomParameterToUrl(String parameterName, String parameterValue) {
        if (mUrlString.contains(parameterName)) {
            return; // Throw an error?
        }
        if (!mUrlString.contains("?")) {
            mUrlString += "?";
        } else if (!mUrlString.endsWith("?")) {
            mUrlString += "&";
        }
        mUrlString += parameterName;
        if (parameterValue != null && !parameterValue.isEmpty()) {
            mUrlString += "=" + parameterValue;
        }
    }
}
