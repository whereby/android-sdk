package com.whereby.sdk;

import static com.whereby.sdk.WherebyConstants.*;
import static com.whereby.sdk.WherebyRoomEventProperties.*;
import static com.whereby.sdk.WherebyRoomEventTypes.*;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;

@SuppressLint("ValidFragment")
public class RoomFragment extends Fragment {
    View mView;

    private final static String TAG = WherebyRoomFragment.class.getSimpleName();

    private WebView mWebView;
    private WherebyRoom mRoom;
    private URL mUrl; // Built out of roomUrl and roomParameters
    private WebAppInterface mWebAppInterface;
    private PermissionsManager mPermissionsManager;

    private WherebyEventListener mEventListener;

    //region Fragment lifecycle
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.whereby_room_fragment, container, false);
        mWebView = mView.findViewById(R.id.webView);
        mPermissionsManager = new PermissionsManager();

        Bundle argumentsBundle = getArguments();
        if (argumentsBundle == null || argumentsBundle.getSerializable(ROOM_ARGUMENT_KEY) == null) {
            showErrorAlertDialog("Failed to load room.");
            return mView;
        }
        WherebyRoom room = (WherebyRoom) argumentsBundle.getSerializable(ROOM_ARGUMENT_KEY);
        if (room.getUrl() == null) {
            showErrorAlertDialog("Room url missing.");
            return mView;
        }
        try {
            mUrl = new UrlBuilder().create(room.getUrl(), room.getParameters());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            showErrorAlertDialog("MalformedURLException.");
            return mView;
        }
//        Log.d(TAG, mUrl.toString());

        this.mRoom = room;

        mWebAppInterface = new WebAppInterface();
        mWebAppInterface.setEventListener(message -> onReceivePostMessage(message));

        WebViewUtils.configureWebView(mWebView, getActivity(), mWebAppInterface, room.getParameters());
        return mView;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (this.mWebView.getUrl() == null) {
            checkMediaPermissionsAndLoadRoom();
        }
    }

    @Override
    public void onStop() {
        mPermissionsManager.onStop();
        super.onStop();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PermissionsManager.PERMISSION_REQUEST_CODE) {
            if (mPermissionsManager.onRequestPermissionsResult(permissions, grantResults, getContext())) {
                this.loadRoomUrl();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public void onDestroy() {
        mWebView.destroy();
        super.onDestroy();
    }
    //endregion

    //region Protected
    protected void join() {
        checkMediaPermissionsAndLoadRoom();
    }

    protected void sendCommand(String command, String args) {
        mWebView.loadUrl("javascript:window.postMessage({ command: \"" + command + "\", args: [" + args + "]})");
    }

    protected void setEventListener(WherebyEventListener eventListener) {
        this.mEventListener = eventListener;
    }
    //endregion

    //region Private
    private void checkMediaPermissionsAndLoadRoom() {
        if (mPermissionsManager == null) {
            return;
        }
        if (!mPermissionsManager.isPendingPermissions(getContext())) {
            this.loadRoomUrl();
        } else if (!mPermissionsManager.mPermissionChecked) {
            requestPermissions(mPermissionsManager.getPendingPermissions(getContext()), PermissionsManager.PERMISSION_REQUEST_CODE);
        }
    }

    private void loadRoomUrl() {
        if (mUrl == null) {
            return;
        }
        this.mWebView.loadUrl(mUrl.toString());
    }


    private void onReceivePostMessage(String message) {
        // Log.d(TAG, message);
        if (!mRoom.isEventBroadcastEnabled() && mEventListener == null) {
            return;
        }

        WherebyRoomEvent wherebyRoomEvent = new WherebyRoomEvent(message);

        if (mRoom.isEventBroadcastEnabled()) {
            Intent intent = new Intent();
            intent.setAction(ROOM_BROADCAST_EVENT_ACTION);
            intent.putExtra(ROOM_BROADCAST_EVENT_NAME,  wherebyRoomEvent);
            LocalBroadcastManager.getInstance(getContext()).sendBroadcast(intent);
        }

        if (mEventListener != null) {
            mEventListener.onEvent(wherebyRoomEvent);
            try {
                switch (wherebyRoomEvent.getType()) {
                    case ROOM_EVENT_TYPE_READY:
                        mEventListener.onReady();
                        break;
                    case ROOM_EVENT_TYPE_JOIN:
                        mEventListener.onJoin();
                        break;
                    case ROOM_EVENT_TYPE_KNOCK:
                        mEventListener.onKnock();
                        break;
                    case ROOM_EVENT_TYPE_PARTICIPANT_JOIN: {
                        JSONObject participant = wherebyRoomEvent.getPayload().getJSONObject(ROOM_EVENT_PROPERTY_PARTICIPANT);
                        mEventListener.onParticipantJoin(participant);
                        break;
                    }
                    case ROOM_EVENT_TYPE_PARTICIPANT_LEAVE: {
                        JSONObject participant = wherebyRoomEvent.getPayload().getJSONObject(ROOM_EVENT_PROPERTY_PARTICIPANT);
                        mEventListener.onParticipantLeave(participant);
                        break;
                    }
                    case ROOM_EVENT_TYPE_PARTICIPANT_UPDATE:
                        int count = wherebyRoomEvent.getPayload().getInt(ROOM_EVENT_PROPERTY_COUNT);
                        mEventListener.onParticipantUpdate(count);
                        break;
                    case ROOM_EVENT_TYPE_MICROPHONE_TOGGLE: {
                        boolean enabled = wherebyRoomEvent.getPayload().getBoolean(ROOM_EVENT_PROPERTY_ENABLED);
                        mEventListener.onMicrophoneToggle(enabled);
                        break;
                    }
                    case ROOM_EVENT_TYPE_CAMERA_TOGGLE: {
                        boolean enabled = wherebyRoomEvent.getPayload().getBoolean(ROOM_EVENT_PROPERTY_ENABLED);
                        mEventListener.onCameraToggle(enabled);
                        break;
                    }
                    case ROOM_EVENT_TYPE_LEAVE:
                        boolean removed = wherebyRoomEvent.getPayload().getBoolean(ROOM_EVENT_PROPERTY_REMOVED);
                        mEventListener.onLeave(removed);
                        break;
                }
            } catch (JSONException e) {
                e.printStackTrace();
                return;
            }
        }
    }


    private void showErrorAlertDialog(String message) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());
        alertDialogBuilder.setTitle("Error");
        alertDialogBuilder.setMessage(message);
        alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        alertDialogBuilder.create().show();
    }
    //endregion
}
