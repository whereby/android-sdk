package com.whereby.sdk;

public final class WherebyRoomEventTypes {
    public static final String ROOM_EVENT_TYPE_READY = "ready";
    public static final String ROOM_EVENT_TYPE_KNOCK = "knock";
    public static final String ROOM_EVENT_TYPE_PARTICIPANT_UPDATE = "participantupdate";
    public static final String ROOM_EVENT_TYPE_JOIN = "join";
    public static final String ROOM_EVENT_TYPE_LEAVE = "leave";
    public static final String ROOM_EVENT_TYPE_PARTICIPANT_JOIN = "participant_join";
    public static final String ROOM_EVENT_TYPE_PARTICIPANT_LEAVE = "participant_leave";
    public static final String ROOM_EVENT_TYPE_MICROPHONE_TOGGLE = "microphone_toggle";
    public static final String ROOM_EVENT_TYPE_CAMERA_TOGGLE = "camera_toggle";
}

final class WherebyRoomEventProperties {
    public static final String ROOM_EVENT_PROPERTY_PARTICIPANT = "participant";
    public static final String ROOM_EVENT_PROPERTY_COUNT = "count";
    public static final String ROOM_EVENT_PROPERTY_ENABLED = "enabled";
    public static final String ROOM_EVENT_PROPERTY_REMOVED = "removed";
}