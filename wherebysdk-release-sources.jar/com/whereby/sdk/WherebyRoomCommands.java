package com.whereby.sdk;

public interface WherebyRoomCommands {

    void sendCommand(String command, String args);

    void toggleMicrophone();
    void toggleMicrophone(boolean enabled);
    void toggleCamera();
    void toggleCamera(boolean enabled);
}
