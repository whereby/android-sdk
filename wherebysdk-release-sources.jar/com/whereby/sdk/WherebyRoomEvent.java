package com.whereby.sdk;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.net.URL;

public class WherebyRoomEvent implements Serializable {

    //{"type":"ready"}
    //{"type":"join"}
    //{"type":"knock"}
    //{"type":"participant_join","payload":{"participant":{"metadata":null}}}
    //{"type":"participant_leave","payload":{"participant":{"metadata":null}}}
    //{"type":"participantupdate","payload":{"count":2}}
    //{"type":"microphone_toggle","payload":{"enabled":false}}
    //{"type":"camera_toggle","payload":{"enabled":false}}
    //{"type":"leave","payload":{"removed":false}}

    private static final String KEY_NAME_TYPE = "type";
    private static final String KEY_NAME_PAYLOAD = "payload";

    private String mType;
    private JSONObject mPayload;
    private String mRaw;

    public WherebyRoomEvent(String rawEvent) {
        try {
            mRaw = rawEvent;
            JSONObject event_json = new JSONObject(rawEvent);
            if (event_json.has(KEY_NAME_TYPE)) {
                mType = event_json.getString(KEY_NAME_TYPE);
            }
            if (event_json.has(KEY_NAME_PAYLOAD)) {
                mPayload = event_json.getJSONObject(KEY_NAME_PAYLOAD);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //region Getters
    public String getType() {
        return mType;
    }

    public JSONObject getPayload() {
        return mPayload;
    }

    public String getRaw() {
        return mRaw;
    }
    //endregion
}

