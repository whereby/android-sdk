package com.whereby.sdk;

import java.io.Serializable;
import java.net.URL;

public class WherebyRoom implements Serializable {

    private URL url;
    private WherebyRoomParameters parameters; // Optional
    private boolean mEventBroadcastEnabled = false;

    public WherebyRoom(URL roomUrl) {
        this.url = roomUrl;
    }

    //region Getters & Setters
    public URL getUrl() {
        return url;
    }

    public void setUrl(URL url) {
        this.url = url;
    }

    public WherebyRoomParameters getParameters() {
        return parameters;
    }

    public void setParameters(WherebyRoomParameters parameters) {
        this.parameters = parameters;
    }

    public boolean isEventBroadcastEnabled() {
        return mEventBroadcastEnabled;
    }

    public void setEventBroadcastEnabled(boolean eventBroadcastEnabled) {
        this.mEventBroadcastEnabled = eventBroadcastEnabled;
    }
    //endregion
}
