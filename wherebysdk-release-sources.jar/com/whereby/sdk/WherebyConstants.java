package com.whereby.sdk;

public class WherebyConstants {
    public static final String ROOM_ARGUMENT_KEY = "ROOM_ARGUMENT_KEY";

    public static final String ROOM_BROADCAST_EVENT_ACTION =  "action" ;//BuildConfig.LIBRARY_PACKAGE_NAME + ".broadcast.WherebyRoomEvent";
    public static final String ROOM_BROADCAST_EVENT_NAME = "event";
}
