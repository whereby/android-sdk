package com.whereby.sdk;

public class WherebyRoomFragment extends RoomFragment implements WherebyRoomCommands {

    private static final String ROOM_COMMAND_TOGGLE_CAMERA = "toggle_camera";
    private static final String ROOM_COMMAND_TOGGLE_MICROPHONE = "toggle_microphone";

    public void join() {
        super.join();
    }

    public void setEventListener(WherebyEventListener eventListener) {
        super.setEventListener(eventListener);
    }

    public void sendCommand(String command, String args) {
        super.sendCommand(command, args);
    }

    @Override
    public void toggleMicrophone() {
        sendCommand(ROOM_COMMAND_TOGGLE_MICROPHONE, "");
    }

    @Override
    public void toggleMicrophone(boolean enabled) {
        sendCommand(ROOM_COMMAND_TOGGLE_MICROPHONE, String.valueOf(enabled));
    }

    @Override
    public void toggleCamera() {
        sendCommand(ROOM_COMMAND_TOGGLE_CAMERA, "");
    }

    @Override
    public void toggleCamera(boolean enabled) {
        sendCommand(ROOM_COMMAND_TOGGLE_CAMERA, String.valueOf(enabled));
    }

}
