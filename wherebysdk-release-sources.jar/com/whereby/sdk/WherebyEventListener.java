package com.whereby.sdk;

import org.json.JSONObject;

// Should this be an interface with default methods or an abstract class?
public interface WherebyEventListener {
    
    /**
     * Report any event, including the events listed below.
     * @param event
     */
    default void onEvent(WherebyRoomEvent event) {}

    default void onReady() {}
    default void onKnock() {}
    default void onJoin() {}
    default void onParticipantJoin(JSONObject participant) {}
    default void onParticipantLeave(JSONObject participant) {}
    default void onParticipantUpdate(int count) {}
    default void onMicrophoneToggle(boolean enabled) {}
    default void onCameraToggle(boolean enabled) {}
    default void onLeave(boolean removed) {}
}