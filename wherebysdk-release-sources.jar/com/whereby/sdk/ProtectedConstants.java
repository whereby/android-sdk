package com.whereby.sdk;

public class ProtectedConstants {
    // This name is used by Javascript to send events to Android (name must match with PWA):
    protected static final String ANDROID_WEB_APP_INTERFACE_NAME = "AndroidWebAppInterface";
}
