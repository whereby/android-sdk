package com.whereby.sdk;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class WherebyRoomActivity extends AppCompatActivity {

    WherebyRoomFragment mRoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.whereby_room_activity);

        mRoom = new WherebyRoomFragment();
        mRoom.setArguments(getIntent().getExtras());

        FragmentManager fm = getFragmentManager();
//      FragmentManager fm = getSupportedFragmentManager(); // with androidx
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
        fragmentTransaction.replace(R.id.layout_fragment_container, mRoom);
        fragmentTransaction.commit();
        mRoom.join();
    }
}
