package com.whereby.sdk;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;

class CustomWebChromeClient extends WebChromeClient {

    private Activity mActivity;

    public CustomWebChromeClient(Activity parentActivity) {
        super();
        mActivity = parentActivity;
    }

    @Override
    public void onPermissionRequest(final PermissionRequest request) {
        mActivity.runOnUiThread(new Runnable() {
            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void run() {
                request.grant(request.getResources());
            }
        });
    }

    @Override
    public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
        return super.onConsoleMessage(consoleMessage);
    }

}
