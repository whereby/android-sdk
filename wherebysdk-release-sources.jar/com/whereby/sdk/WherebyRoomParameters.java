package com.whereby.sdk;

import android.text.TextUtils;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.HashMap;

public class WherebyRoomParameters implements Serializable {

    private HashMap<String, String> customParameters = new HashMap();

    //region Properties using field reflection (do not rename)
    private String displayName;
    private String lang;
    private String metadata;
    private String sdkVersion; // Not settable nor gettable

    private String[] groups;

    private URL avatarUrl;

    private Boolean minimal;
    private Boolean audio;
    private Boolean video;
    private Boolean background;
    private Boolean chat;
    private Boolean people;
    private Boolean leaveButton;
    private Boolean subgridLabels;
    private Boolean floatSelf;
    private Boolean logo;
    private Boolean locking;
    private Boolean participantCount;
    private Boolean settingsButton;
    private Boolean moreButton;
    private Boolean topToolbar;
    private Boolean breakout;
    private Boolean timer;
    private Boolean precallReview;
    private Boolean personality;

    private Boolean needancestor = true;
    private Boolean skipMediaPermissionPrompt = true;
    //endregion

    public WherebyRoomParameters() {
        setupSdkVersion();
    }

    protected HashMap<String, String> toHashMap() {
        HashMap<String, String> definedParametersHashMap = new HashMap();
        for (Field field : getClass().getDeclaredFields()) {
            try {
                Object object = field.get(this);
                if (object == null) {
                    continue;
                }
                if (field.getType() == Boolean.class) {
                    definedParametersHashMap.put(field.getName(), (Boolean) object ? "on" : "off");
                } else if (field.getType() == String.class) {
                    definedParametersHashMap.put(field.getName(), (String) object);
                } else if (field.getType() == String[].class) {
                    definedParametersHashMap.put(field.getName(), TextUtils.join(",", (String[]) object));
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        HashMap<String, String> allParametersHashMap = new HashMap<>();
        allParametersHashMap.putAll(customParameters);
        allParametersHashMap.putAll(definedParametersHashMap);
        return allParametersHashMap;
    }

    //region Private
    private void setupSdkVersion() {
//        sdkVersion = "android-" + BuildConfig.WHEREBY_VERSION_NAME;
//        if (BuildConfig.DEBUG) {
//            sdkVersion += "-debug";
//        }
    }
    //endregion

    //region protected Getters & Setters
    protected String getSdkVersion() {
        return sdkVersion;
    }
    //endregion

    //region public Getters & Setters
    public HashMap<String, String> getCustomParameters() {
        return customParameters;
    }

    public void addCustomParameter(String parameterName, String parameterValue) {
        customParameters.put(parameterName, parameterValue);
    }

    /**
     * Set the display name for a participant instead of prompting the user for this information.
     * Use case: A participant’s name may be known before they join the meeting. Setting the
     * displayName will save the user from entering their name again.
     *
     * @param displayName
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    /**
     * Set the meeting UI language to match your product or service.
     *
     * @param lang
     */
    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getLang() {
        return lang;
    }

    /**
     * Predefine up to 20 groups for the breakout groups function.
     * Use case: Setting up groups ahead of time can save the host time during the meeting. Hosts
     * will still be able to modify the group setup during the session using the in-room controls
     * if needed.
     *
     * @param groups
     */
    public void setGroups(String[] groups) {
        this.groups = groups;
    }

    public String[] getGroups() {
        return groups;
    }

    /**
     * Set the avatar / profile picture of the participant instead of the automatically assigned
     * name initials. The image can be a .png or .jpeg, and must be a square maximum of 64x64.
     * Note: You must make sure to list the origin of the image URL in the allowed domains section
     * of the dashboard. The image URL must be https and cannot contain query params.
     *
     * @param avatarUrl
     */
    public void setAvatarUrl(URL avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public URL getAvatarUrl() {
        return avatarUrl;
    }

    /**
     * Can be used to pass any URL-encoded string so that it is included in the corresponding
     * webhooks. The decoded string has a limit of 512 characters.
     * Use case: Set it to the user’s ID so that you can easily track through webhooks when a
     * particular user joins or leaves a room.
     *
     * @param metadata
     */
    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    public String getMetadata() {
        return metadata;
    }

    /**
     * The minimal configuration applies a combination of UI adjustments to simplify the embedded
     * meeting interface.
     * Hidden items: Status bar, chat button, leave button, and Whereby’s branding.
     * Shown items: Video and audio buttons.
     * For further adjustments, additional parameters can be combined with minimal configuration.
     *
     * @param enabled
     */
    public void setMinimalConfigurationEnabled(Boolean enabled) {
        this.minimal = enabled;
    }

    public Boolean isMinimalConfigurationEnabled() {
        return minimal;
    }

    /**
     * Participants join the meeting with their microphone on (enabled) or off (disabled), they can
     * then turn it off/on whenever they want.
     * Use case: A presentation is being given in a big meeting where attendees are not expected to
     * participate verbally.
     *
     * @param enabled
     */
    public void setMicrophoneEnabledAtStart(Boolean enabled) {
        this.audio = enabled;
    }

    public Boolean isMicrophoneEnabledAtStart() {
        return audio;
    }

    /**
     * Participants join the meeting with their camera on (enabled) or off (disabled), they can then
     * turn it off/on whenever they want.
     * Use case: A sales representative showcasing a product to a customer relaxing at home.
     *
     * @param enabled
     */
    public void setCameraEnabledAtStart(Boolean enabled) {
        this.video = enabled;
    }

    public Boolean isCameraEnabledAtStart() {
        return video;
    }

    /**
     * Enable (show) or disable (hide) the default meeting background.
     * Use case: Hiding the meeting background allows the meeting to appear more integrated by
     * allowing the app or service’s branding shine through as the new background.
     *
     * @param enabled
     */
    public void setBackgroundEnabled(Boolean enabled) {
        this.background = background;
    }

    public Boolean isBackgroundEnabled() {
        return background;
    }

    /**
     * Show/hide the chat button. Messages are not stored after the meeting has ended.
     *
     * @param visible
     */
    public void setChatButtonVisible(Boolean visible) {
        this.chat = visible;
    }

    public Boolean isChatButtonVisible() {
        return chat;
    }

    /**
     * Show/hide the people button.
     * Use case: The people button shows the participant list, which can be useful for bulk
     * management of participants in bigger meetings.
     *
     * @param visible
     */

    public void setPeopleButtonVisible(Boolean visible) {
        this.people = visible;
    }

    public Boolean isPeopleButtonVisible() {
        return people;
    }

    /**
     * Show/hide the leave button.
     * Use case: Can be used if you want to control the leave flow in other ways, like adding a
     * button outside the embedded room to control what happens when users leave the call.
     *
     * @param visible
     */
    public void setLeaveButtonVisible(Boolean visible) {
        this.leaveButton = visible;
    }

    public Boolean isLeaveButtonVisible() {
        return leaveButton;
    }

    /**
     * Show/hide the name labels for the participants in the subgrid.
     * Use case: Set this to visible to show name labels for the participants that are rendered as
     * small tiles in the subgrid. Makes it easier to distinguish participants with their camera
     * off.
     *
     * @param visible
     */
    public void setSubgridLabelsVisible(Boolean visible) {
        this.subgridLabels = visible;
    }

    public Boolean isSubgridLabelsVisible() {
        return subgridLabels;
    }

    /**
     * Float the self view to the bottom right.
     * Use case: Floating the self view to the bottom right maximizes the space for other meeting
     * participants.
     *
     * @param enabled
     */
    public void setFloatSelfViewEnabled(Boolean enabled) {
        this.floatSelf = enabled;
    }

    public Boolean isFloatSelfViewEnabled() {
        return floatSelf;
    }

    /**
     * Show/hide the logo in the room header.
     * Use case: Control whether or not your company logo is displayed in the room header.
     *
     * @param visible
     */
    public void setLogoVisible(Boolean visible) {
        this.logo = visible;
    }

    public Boolean isLogoVisible() {
        return logo;
    }

    /**
     * Enable/disable the room lock feature.
     * Use case: When disabled the lock button won’t be displayed in the room header. Also, hosts
     * won’t be able to lock/unlock the room through the settings menu or the keyboard shortcut.
     *
     * @param enabled
     */
    public void setLockingEnabled(Boolean enabled) {
        this.locking = enabled;
    }

    public Boolean isLockingEnabled() {
        return locking;
    }

    /**
     * Show/hide the participant counter.
     * Use case: Will display the current and maximum number of participants in the room, e.g.
     * “2/4” or “13/100”.
     *
     * @param visible
     */
    public void setParticipantCounterVisible(Boolean visible) {
        this.participantCount = visible;
    }

    public Boolean isParticipantCounterVisible() {
        return participantCount;
    }

    /**
     * Show/hide the settings button.
     * Use case: Control whether or not the settings button is displayed in the room header.
     *
     * @param visible
     */
    public void setSettingsButtonVisible(Boolean visible) {
        this.settingsButton = visible;
    }

    public Boolean isSettingsButtonVisible() {
        return settingsButton;
    }

    /***
     * Show/Hide the more (“…”) button.
     * Use case: Control whether or not the more (“…”) button is displayed in the room header.
     *
     * @param visible
     */
    public void setMoreButtonVisible(Boolean visible) {
        this.moreButton = visible;
    }

    public Boolean isMoreButtonVisible() {
        return moreButton;
    }

    /**
     * Show/hide the entire top toolbar.
     * Use case: When using the minimal configuration, the top toolbar is hidden along with many
     * other UI elements. This parameter will cause the top toolbar to reappear, which is required
     * if you want to enable breakout groups, for instance.
     *
     * @param visible
     */
    public void setTopToolbarVisible(Boolean visible) {
        this.topToolbar = visible;
    }

    public Boolean isTopToolbarVisible() {
        return topToolbar;
    }

    /**
     * Enable/disable the Breakout Groups feature for the meeting host.
     * Use case: Combine bigger meetings with smaller, collaborative sessions. Your hosts can start
     * breakout sessions where participants are split into smaller groups.
     *
     * @param enabled
     */
    public void setBreakoutGroupsEnabled(Boolean enabled) {
        this.breakout = enabled;
    }

    public Boolean isBreakoutGroupsEnabled() {
        return breakout;
    }

    /**
     * Show/hide the meeting timer.
     * Use case: Enable this to have the meeting timer be displayed in the room. When disabled,
     * room hosts can still activate the meeting timer from the “…” button, unless this button has
     * been hidden.
     *
     * @param visible
     */
    public void setTimerVisible(Boolean visible) {
        this.timer = visible;
    }

    public Boolean isTimerVisible() {
        return timer;
    }

    /**
     * Determines if users see the pre-call review step.
     * Use case: The pre-call review step will allow users to check their video/audio settings
     * before joining the room.
     *
     * @param enabled
     */
    public void setPreCallReviewScreenEnabled(Boolean enabled) {
        this.precallReview = enabled;
    }

    public Boolean isPreCallReviewScreenEnabled() {
        return precallReview;
    }

    /**
     * Can be used to turn off “cheery” UI language that may not fit certain businesses.
     * Use case: Disable this to use more neutral language for certain text strings, like replacing
     * “Have a good one!” with “You’ve left the room” when participants leave the room.
     *
     * @param enabled
     */
    public void setPersonalityEnabled(Boolean enabled) {
        this.personality = enabled;
    }

    public Boolean isPersonalityEnabled() {
        return personality;
    }

    /**
     * Skip to media permission screen. This is needed on mobile.
     *
     * @param enabled
     */
    public void setSkipMediaPermissionPromptEnabled(Boolean enabled) {
        this.skipMediaPermissionPrompt = enabled;
    }

    public Boolean isSkipMediaPermissionPromptEnabled() {
        return skipMediaPermissionPrompt;
    }

    public void setNeedAncestorEnabled(Boolean enabled) {
        this.needancestor = enabled;
    }

    public Boolean isNeedAncestorEnabled() {
        return needancestor;
    }
    //endregion

}
