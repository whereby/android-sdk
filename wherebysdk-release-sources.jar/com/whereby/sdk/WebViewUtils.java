package com.whereby.sdk;

import static com.whereby.sdk.ProtectedConstants.*;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

class WebViewUtils {

    @SuppressLint("SetJavaScriptEnabled")
    public static void configureWebView(WebView webView, Activity activity, WebAppInterface webAppInterface, WherebyRoomParameters roomParameters) {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new CustomWebChromeClient(activity));
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(webAppInterface, ANDROID_WEB_APP_INTERFACE_NAME);

        if (roomParameters.isBackgroundEnabled() != null && !roomParameters.isBackgroundEnabled()) {
            webView.setBackgroundColor(Color.TRANSPARENT);
        }
    }
}
